#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
#include <syslog.h>          /* logging */
#include <byteswap.h>
#include <stdbool.h>
#include "it2s-mac.h"
#include <inttypes.h>
#include <time.h>

#define syslog_emerg(msg, ...) syslog(LOG_EMERG, "%s(%s:%d) [" msg "]", __FILE__, __func__, __LINE__, ##__VA_ARGS__)
#define syslog_err(msg, ...)   syslog(LOG_ERR  , "%s(%s:%d) [" msg "]", __FILE__, __func__, __LINE__, ##__VA_ARGS__)

#ifndef NDEBUG
#define syslog_debug(msg, ...) syslog(LOG_DEBUG, "%s:%d [" msg "]", __func__, __LINE__, ##__VA_ARGS__)
#else
#define syslog_debug(msg, ...)
#endif

/* Function to reverse bits of num */
inline uint8_t reverseBits(uint8_t num){
	uint8_t reverse_num = 0x00;
	// Reverse
	reverse_num = lookuptable[ num & 0xff ];
	return reverse_num;
}

int it2s_mac_add_headers_without_inversion(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size){
	uint8_t *dst_ptr;
	uint8_t *src_ptr;
	int i;

	if ( (src_packet == NULL) || (dst_packet == NULL) || (dst_msg_size == NULL) ){
		syslog_emerg("it2s_mac_add_headers() failed: NULL pointer detected!");
		return EBADMSG;
	}

	// Calculate destination size
	*dst_msg_size = src_msg_size + ( L_DATA_DATA - 12);

	dst_ptr = dst_packet;
	src_ptr = src_packet;

	// FC
	*(dst_ptr) = 0x08; 
	*(dst_ptr + 1) = 0x00;
	// Duration/ID
	*(dst_ptr + L_FC) = 0x00; 
	*(dst_ptr + L_FC + 1) = 0x00;
	// DA
	memcpy (dst_ptr + L_FC + L_DURATION, src_packet, L_ADDR1);
	// SA
	memcpy (dst_ptr + L_FC + L_DURATION + L_ADDR1, src_packet + L_ADDR1, L_ADDR2);
	// BSSID
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 1) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 2) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 3) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 4) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 5) = 0xFF;
	// Sequence Control 
	*((uint16_t *)(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3)) = bswap_16(0x307A);
	// Copy Remaining message	
	memcpy(dst_ptr + L_DATA_DATA, src_ptr + L_ADDR1 + L_ADDR2, src_msg_size - (L_ADDR1 + L_ADDR2));

	return 0;
}

int it2s_mac_add_headers(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size){
	uint8_t *dst_ptr;
	uint8_t *src_ptr;
	uint8_t *inverted;
	int i;

	if ( (src_packet == NULL) || (dst_packet == NULL) || (dst_msg_size == NULL) ){
		syslog_emerg("it2s_mac_add_headers() failed: NULL pointer detected!");
		return EBADMSG;
	}

	// Calculate destination size
	*dst_msg_size = src_msg_size + ( L_DATA_DATA - 12);

	dst_ptr = dst_packet;
	src_ptr = src_packet;

	// FC
	*(dst_ptr) = 0x08; 
	*(dst_ptr + 1) = 0x00;
	// Duration/ID
	*(dst_ptr + L_FC) = 0x00; 
	*(dst_ptr + L_FC + 1) = 0x00;
	// DA
	memcpy (dst_ptr + L_FC + L_DURATION, src_packet, L_ADDR1);
	// SA
	memcpy (dst_ptr + L_FC + L_DURATION + L_ADDR1, src_packet + L_ADDR1, L_ADDR2);
	// BSSID
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 1) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 2) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 3) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 4) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 5) = 0xFF;
	// Sequence Control 
	*((uint16_t *)(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3)) = bswap_16(0x307A);
	// Copy Remaining message	
	memcpy(dst_ptr + L_DATA_DATA, src_ptr + L_ADDR1 + L_ADDR2, src_msg_size - (L_ADDR1 + L_ADDR2));

	// Invert bytes
	src_ptr = dst_packet;
	dst_ptr = dst_packet;
	for (i=0; i < *dst_msg_size; i++){
		*(dst_ptr++) = reverseBits(*(src_ptr++));
	}

	return 0;
}

int it2s_mac_remove_headers_without_inversion(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size){
	uint8_t *ptr;
	uint8_t *src_ptr;
	uint8_t *dst_ptr;
	uint16_t uint16bit;
	uint8_t uint8bit;
	uint8_t uint8bit_tmp;
	uint16_t mac_header_size;
	int i;
	uint8_t type;
	uint8_t stype;
	bool tods;
	bool fromds;

#ifndef NDEBUG
	uint8_t protocol_version;
	uint8_t mac1_byte1;
	uint8_t mac1_byte2;
	uint8_t mac1_byte3;
	uint8_t mac1_byte4;
	uint8_t mac1_byte5;
	uint8_t mac1_byte6;
	uint8_t mac2_byte1;
	uint8_t mac2_byte2;
	uint8_t mac2_byte3;
	uint8_t mac2_byte4;
	uint8_t mac2_byte5;
	uint8_t mac2_byte6;
	uint8_t mac3_byte1;
	uint8_t mac3_byte2;
	uint8_t mac3_byte3;
	uint8_t mac3_byte4;
	uint8_t mac3_byte5;
	uint8_t mac3_byte6;
	uint8_t mac4_byte1;
	uint8_t mac4_byte2;
	uint8_t mac4_byte3;
	uint8_t mac4_byte4;
	uint8_t mac4_byte5;
	uint8_t mac4_byte6;
	uint16_t sq_sequence_number;
	uint16_t sq_frag_number;
	uint16_t duration_id;
	bool more_frag;
	bool retry;
	bool pwr_mgt;
	bool more_data;
	bool prf;
	bool order;
	bool duration_id_flag;
#endif

	if ( (src_packet == NULL) || (dst_packet == NULL) || (dst_msg_size == NULL) ){
		syslog_emerg("it2s_mac_remove_headers() failed: NULL pointer detected!");
		return EBADMSG;
	}

	// Keep Inverted pointer Safe.
	ptr = src_packet;

#ifndef NDEBUG
	// Begin Decoding Frame Debug mode 
	// Frame Control
	// PV
	uint8bit = *ptr;
	protocol_version = (uint8bit & M_PV);
	syslog_debug("MAC Protocol Version: %u", protocol_version);
	// Type
	type = (uint8bit & M_TYPE) >> 2;
	syslog_debug("MAC Protocol Type: %u", type);
	// Subtype
	stype = (uint8bit & M_S_TYPE) >> 4;
	syslog_debug("MAC Protocol Subtype: %u", stype);
	// FLAGS
	uint8bit = *(ptr + 1);
	// To DS
	uint8bit_tmp = (uint8bit & M_FLAGS_TO_DS);
	tods = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol To DS: %d", tods);
	// From DS
	uint8bit_tmp = (uint8bit & M_FLAGS_FROM_DS) >> 1;
	fromds = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol From DS: %d", fromds);
	// More Frag
	uint8bit_tmp = (uint8bit & M_FLAGS_MORE_FRAG) >> 2;
	more_frag = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol More Frag: %d", more_frag);
	// Retry
	uint8bit_tmp = (uint8bit & M_FLAGS_RETRY) >> 3;
	retry = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol Retry: %d", retry);
	// Pwr Mgt
	uint8bit_tmp = (uint8bit & M_FLAGS_PWR_MGT) >> 4;
	pwr_mgt = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol Pwr Mgt: %d", pwr_mgt);
	// More Data
	uint8bit_tmp = (uint8bit & M_FLAGS_MORE_DATA) >> 5;
	more_data = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol More Data: %d", more_data);
	// PrF
	uint8bit_tmp = (uint8bit & M_FLAGS_PRF) >> 6;
	prf = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol PrF: %d", prf);
	// Order
	uint8bit_tmp = (uint8bit & M_FLAGS_ORDER) >> 7;
	order = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol Order: %d", order);
	// Duration
	// Already bswaped_16!
	uint16bit = *((uint16_t *)(ptr + L_FC));
	duration_id = (uint16bit & M_DURATION_ID_FLAG) >> 15;
	duration_id_flag = (duration_id == 1) ? true : false;
	syslog_debug("MAC Protocol Duration/ID flag: %d", duration_id_flag);
	if (duration_id_flag == 0){
		duration_id = (uint16bit & M_DURATION_ID_DURATION);
		syslog_debug("MAC Protocol Duration/ID: %u", duration_id);
	} else {
		syslog_debug("MAC Protocol Duration/ID: ID type found!");
	}
	// Address 1
	mac1_byte1 = *(ptr + L_FC + L_DURATION);
	mac1_byte2 = *(ptr + L_FC + L_DURATION + 1);
	mac1_byte3 = *(ptr + L_FC + L_DURATION + 2);
	mac1_byte4 = *(ptr + L_FC + L_DURATION + 3);
	mac1_byte5 = *(ptr + L_FC + L_DURATION + 4);
	mac1_byte6 = *(ptr + L_FC + L_DURATION + 5);
	syslog_debug("MAC Protocol Address 1: %02X:%02X:%02X:%02X:%02X:%02X",mac1_byte1, mac1_byte2, mac1_byte3, mac1_byte4, mac1_byte5, mac1_byte6);
	// Address 2
	mac2_byte1 = *(ptr + L_FC + L_DURATION + L_ADDR1);
	mac2_byte2 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 1);
	mac2_byte3 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 2);
	mac2_byte4 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 3);
	mac2_byte5 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 4);
	mac2_byte6 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 5);
	syslog_debug("MAC Protocol Address 2: %02X:%02X:%02X:%02X:%02X:%02X",mac2_byte1, mac2_byte2, mac2_byte3, mac2_byte4, mac2_byte5, mac2_byte6);
	// Address 3
	mac3_byte1 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2);
	mac3_byte2 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 1);
	mac3_byte3 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 2);
	mac3_byte4 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 3);
	mac3_byte5 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 4);
	mac3_byte6 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 5);
	syslog_debug("MAC Protocol Address 3: %02X:%02X:%02X:%02X:%02X:%02X",mac3_byte1, mac3_byte2, mac3_byte3, mac3_byte4, mac3_byte5, mac3_byte6);
	// Sequence Control
	// Already bswaped_16!
	uint16bit = *((uint16_t *)(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3));
	syslog_debug("MAC Protocol Sequence Control: 0x%04X",uint16bit);
	sq_frag_number = (uint16bit & M_SQ_FRAG_NUMBER);
	syslog_debug("MAC Protocol Sequence Control Frag Number: %u", sq_frag_number);
	sq_sequence_number = (uint16bit & M_SQ_SEQUENCE_NUMBER) >> 4;
	syslog_debug("MAC Protocol Sequence Control Sequence Number: %u", sq_sequence_number);
	if ((tods == true) && (fromds == true) ){	
		// Address 4
		mac4_byte1 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ);
		mac4_byte2 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 1);
		mac4_byte3 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 2);
		mac4_byte4 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 3);
		mac4_byte5 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 4);
		mac4_byte6 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 5);
		syslog_debug("MAC Protocol Address 4: %02X:%02X:%02X:%02X:%02X:%02X",mac4_byte1, mac4_byte2, mac4_byte3, mac4_byte4, mac4_byte5, mac4_byte6);
	}
	if ( (type == 2) && (stype == 8)){
		if ((tods == true) && (fromds == true) ){	
			// QoS Control
			// Already bswaped_16!
			uint16bit = *((uint16_t *)(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + L_ADDR4));
			syslog_debug("MAC Protocol QoS: 0x%04X", uint16bit);
		} else{
			// QoS Control
			// Already bswaped_16!
			uint16bit = *((uint16_t *)(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ));
			syslog_debug("MAC Protocol QoS: 0x%04X", uint16bit);
		}
	}
#else
	// Type
	uint8bit = *ptr;
	type = (uint8bit & M_TYPE) >> 2;
	// Subtype
	stype = (uint8bit & M_S_TYPE) >> 4;
	// FLAGS
	uint8bit = *(ptr + 1);
	// To DS
	uint8bit_tmp = (uint8bit & M_FLAGS_TO_DS);
	tods = (uint8bit_tmp == 1) ? true : false;
	// From DS
	uint8bit_tmp = (uint8bit & M_FLAGS_FROM_DS) >> 1;
	fromds = (uint8bit_tmp == 1) ? true : false;
#endif

	// Evaluate mac_header_size;
	switch (type){
		case 0:
			switch(stype){
				case 4:
					mac_header_size = 24;
					break;
				default:
					return EBADMSG;
					break;
			}
			break;
		case 2:
			switch(stype){
				case 0:
					if ((tods == true) && (fromds == true) ){
						mac_header_size = 30;
					}else{
						mac_header_size = 24;
					}
					break;
				case 8:
					if ((tods == true) && (fromds == true) ){
						mac_header_size = 32;
					}else{
						mac_header_size = 26;
					}
					break;
				default:
					return EBADMSG;
					break;
			}
			break;
		default:
			return EBADMSG;
			break;
	}

	// Start fill short mac | MAC_DST | MAC_SRC | Payload
	dst_ptr = dst_packet;
	if ((!tods) && (!fromds)){
		// DA = Address 1 SA = Address 2
		// DA
		*(dst_ptr) = *(ptr + L_FC + L_DURATION);
		*(dst_ptr + 1) = *(ptr + L_FC + L_DURATION + 1);
		*(dst_ptr + 2) = *(ptr + L_FC + L_DURATION + 2);
		*(dst_ptr + 3) = *(ptr + L_FC + L_DURATION + 3);
		*(dst_ptr + 4) = *(ptr + L_FC + L_DURATION + 4);
		*(dst_ptr + 5) = *(ptr + L_FC + L_DURATION + 5);
		// SA
		*(dst_ptr + L_ADDR1) = *(ptr + L_FC + L_DURATION + L_ADDR1);
		*(dst_ptr + L_ADDR1 + 1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 1);
		*(dst_ptr + L_ADDR1 + 2) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 2);
		*(dst_ptr + L_ADDR1 + 3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 3);
		*(dst_ptr + L_ADDR1 + 4) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 4);
		*(dst_ptr + L_ADDR1 + 5) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 5);
		memcpy( (dst_ptr + L_ADDR1 + L_ADDR2), (src_packet + mac_header_size), ( (src_msg_size + 12) - mac_header_size)); 
		*dst_msg_size = ((src_msg_size + 12) - mac_header_size); 
	} else if ((!tods) && (fromds)){
		// DA = Address 1 SA = Address 3
		// DA
		*(dst_ptr) = *(ptr + L_FC + L_DURATION);
		*(dst_ptr + 1) = *(ptr + L_FC + L_DURATION + 1);
		*(dst_ptr + 2) = *(ptr + L_FC + L_DURATION + 2);
		*(dst_ptr + 3) = *(ptr + L_FC + L_DURATION + 3);
		*(dst_ptr + 4) = *(ptr + L_FC + L_DURATION + 4);
		*(dst_ptr + 5) = *(ptr + L_FC + L_DURATION + 5);
		// SA
		*(dst_ptr + L_ADDR1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2);
		*(dst_ptr + L_ADDR1 + 1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 1);
		*(dst_ptr + L_ADDR1 + 2) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 2);
		*(dst_ptr + L_ADDR1 + 3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 3);
		*(dst_ptr + L_ADDR1 + 4) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 4);
		*(dst_ptr + L_ADDR1 + 5) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 5);
		memcpy( (dst_ptr + L_ADDR1 + L_ADDR3), (src_packet + mac_header_size), ((src_msg_size + 12) - mac_header_size)); 
		*dst_msg_size = (src_msg_size + 12) - mac_header_size; 
	} else if ((tods) && (!fromds)){
		// DA = Address 3 SA = Address 2
		// DA
		*(dst_ptr) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2);
		*(dst_ptr + 1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 1);
		*(dst_ptr + 2) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 2);
		*(dst_ptr + 3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 3);
		*(dst_ptr + 4) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 4);
		*(dst_ptr + 5) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 5);
		// SA
		*(dst_ptr + L_ADDR3) = *(ptr + L_FC + L_DURATION + L_ADDR1);
		*(dst_ptr + L_ADDR3 + 1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 1);
		*(dst_ptr + L_ADDR3 + 2) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 2);
		*(dst_ptr + L_ADDR3 + 3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 3);
		*(dst_ptr + L_ADDR3 + 4) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 4);
		*(dst_ptr + L_ADDR3 + 5) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 5);
		// Add Inverted packet from LLC layer.
		memcpy( (dst_ptr + L_ADDR3 + L_ADDR2), (src_packet + mac_header_size), ((src_msg_size + 12) - mac_header_size)); 
		*dst_msg_size = (src_msg_size + 12) - mac_header_size; 
	} else if ((tods) && (fromds)){
		// DA = Address 3 SA = Address 4
		// DA
		*(dst_ptr) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2);
		*(dst_ptr + 1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 1);
		*(dst_ptr + 2) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 2);
		*(dst_ptr + 3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 3);
		*(dst_ptr + 4) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 4);
		*(dst_ptr + 5) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 5);
		// SA
		*(dst_ptr + L_ADDR3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ);
		*(dst_ptr + L_ADDR3 + 1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 1);
		*(dst_ptr + L_ADDR3 + 2) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 2);
		*(dst_ptr + L_ADDR3 + 3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 3);
		*(dst_ptr + L_ADDR3 + 4) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 4);
		*(dst_ptr + L_ADDR3 + 5) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 5);
		// Add Inverted packet from LLC layer.
		memcpy( (dst_ptr + L_ADDR3 + L_ADDR4), (src_packet + mac_header_size), ((src_msg_size + 12) - mac_header_size));
		*dst_msg_size = (src_msg_size + 12) - mac_header_size; 
	} else {
		// This should be Impossible!
		return EBADMSG;
	}

	return 0;
}

int it2s_mac_remove_headers(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size){
	uint8_t *ptr;
	uint8_t *src_ptr;
	uint8_t *dst_ptr;
	uint16_t uint16bit;
	uint8_t uint8bit;
	uint8_t uint8bit_tmp;
	uint16_t mac_header_size;
	int i;
	uint8_t type;
	uint8_t stype;
	bool tods;
	bool fromds;

#ifndef NDEBUG
	uint8_t protocol_version;
	uint8_t mac1_byte1;
	uint8_t mac1_byte2;
	uint8_t mac1_byte3;
	uint8_t mac1_byte4;
	uint8_t mac1_byte5;
	uint8_t mac1_byte6;
	uint8_t mac2_byte1;
	uint8_t mac2_byte2;
	uint8_t mac2_byte3;
	uint8_t mac2_byte4;
	uint8_t mac2_byte5;
	uint8_t mac2_byte6;
	uint8_t mac3_byte1;
	uint8_t mac3_byte2;
	uint8_t mac3_byte3;
	uint8_t mac3_byte4;
	uint8_t mac3_byte5;
	uint8_t mac3_byte6;
	uint8_t mac4_byte1;
	uint8_t mac4_byte2;
	uint8_t mac4_byte3;
	uint8_t mac4_byte4;
	uint8_t mac4_byte5;
	uint8_t mac4_byte6;
	uint16_t sq_sequence_number;
	uint16_t sq_frag_number;
	uint16_t duration_id;
	bool more_frag;
	bool retry;
	bool pwr_mgt;
	bool more_data;
	bool prf;
	bool order;
	bool duration_id_flag;
#endif

	if ( (src_packet == NULL) || (dst_packet == NULL) || (dst_msg_size == NULL) ){
		syslog_emerg("it2s_mac_remove_headers() failed: NULL pointer detected!");
		return EBADMSG;
	}

	// Invert bytes Warning: overwriting source packet
	src_ptr = src_packet;
	dst_ptr = src_packet;
	for (i=0; i < src_msg_size; i++){
		*(dst_ptr++) = reverseBits(*(src_ptr++));
	}

	// Keep Inverted pointer Safe.
	ptr = src_packet;

#ifndef NDEBUG
	// Begin Decoding Frame Debug mode 
	// Frame Control
	// PV
	uint8bit = *ptr;
	protocol_version = (uint8bit & M_PV);
	syslog_debug("MAC Protocol Version: %u", protocol_version);
	// Type
	type = (uint8bit & M_TYPE) >> 2;
	syslog_debug("MAC Protocol Type: %u", type);
	// Subtype
	stype = (uint8bit & M_S_TYPE) >> 4;
	syslog_debug("MAC Protocol Subtype: %u", stype);
	// FLAGS
	uint8bit = *(ptr + 1);
	// To DS
	uint8bit_tmp = (uint8bit & M_FLAGS_TO_DS);
	tods = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol To DS: %d", tods);
	// From DS
	uint8bit_tmp = (uint8bit & M_FLAGS_FROM_DS) >> 1;
	fromds = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol From DS: %d", fromds);
	// More Frag
	uint8bit_tmp = (uint8bit & M_FLAGS_MORE_FRAG) >> 2;
	more_frag = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol More Frag: %d", more_frag);
	// Retry
	uint8bit_tmp = (uint8bit & M_FLAGS_RETRY) >> 3;
	retry = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol Retry: %d", retry);
	// Pwr Mgt
	uint8bit_tmp = (uint8bit & M_FLAGS_PWR_MGT) >> 4;
	pwr_mgt = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol Pwr Mgt: %d", pwr_mgt);
	// More Data
	uint8bit_tmp = (uint8bit & M_FLAGS_MORE_DATA) >> 5;
	more_data = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol More Data: %d", more_data);
	// PrF
	uint8bit_tmp = (uint8bit & M_FLAGS_PRF) >> 6;
	prf = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol PrF: %d", prf);
	// Order
	uint8bit_tmp = (uint8bit & M_FLAGS_ORDER) >> 7;
	order = (uint8bit_tmp == 1) ? true : false;
	syslog_debug("MAC Protocol Order: %d", order);
	// Duration
	// Already bswaped_16!
	uint16bit = *((uint16_t *)(ptr + L_FC));
	duration_id = (uint16bit & M_DURATION_ID_FLAG) >> 15;
	duration_id_flag = (duration_id == 1) ? true : false;
	syslog_debug("MAC Protocol Duration/ID flag: %d", duration_id_flag);
	if (duration_id_flag == 0){
		duration_id = (uint16bit & M_DURATION_ID_DURATION);
		syslog_debug("MAC Protocol Duration/ID: %u", duration_id);
	} else {
		syslog_debug("MAC Protocol Duration/ID: ID type found!");
	}
	// Address 1
	mac1_byte1 = *(ptr + L_FC + L_DURATION);
	mac1_byte2 = *(ptr + L_FC + L_DURATION + 1);
	mac1_byte3 = *(ptr + L_FC + L_DURATION + 2);
	mac1_byte4 = *(ptr + L_FC + L_DURATION + 3);
	mac1_byte5 = *(ptr + L_FC + L_DURATION + 4);
	mac1_byte6 = *(ptr + L_FC + L_DURATION + 5);
	syslog_debug("MAC Protocol Address 1: %02X:%02X:%02X:%02X:%02X:%02X",mac1_byte1, mac1_byte2, mac1_byte3, mac1_byte4, mac1_byte5, mac1_byte6);
	// Address 2
	mac2_byte1 = *(ptr + L_FC + L_DURATION + L_ADDR1);
	mac2_byte2 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 1);
	mac2_byte3 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 2);
	mac2_byte4 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 3);
	mac2_byte5 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 4);
	mac2_byte6 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 5);
	syslog_debug("MAC Protocol Address 2: %02X:%02X:%02X:%02X:%02X:%02X",mac2_byte1, mac2_byte2, mac2_byte3, mac2_byte4, mac2_byte5, mac2_byte6);
	// Address 3
	mac3_byte1 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2);
	mac3_byte2 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 1);
	mac3_byte3 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 2);
	mac3_byte4 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 3);
	mac3_byte5 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 4);
	mac3_byte6 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 5);
	syslog_debug("MAC Protocol Address 3: %02X:%02X:%02X:%02X:%02X:%02X",mac3_byte1, mac3_byte2, mac3_byte3, mac3_byte4, mac3_byte5, mac3_byte6);
	// Sequence Control
	// Already bswaped_16!
	uint16bit = *((uint16_t *)(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3));
	syslog_debug("MAC Protocol Sequence Control: 0x%04X",uint16bit);
	sq_frag_number = (uint16bit & M_SQ_FRAG_NUMBER);
	syslog_debug("MAC Protocol Sequence Control Frag Number: %u", sq_frag_number);
	sq_sequence_number = (uint16bit & M_SQ_SEQUENCE_NUMBER) >> 4;
	syslog_debug("MAC Protocol Sequence Control Sequence Number: %u", sq_sequence_number);
	if ((tods == true) && (fromds == true) ){	
		// Address 4
		mac4_byte1 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ);
		mac4_byte2 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 1);
		mac4_byte3 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 2);
		mac4_byte4 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 3);
		mac4_byte5 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 4);
		mac4_byte6 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 5);
		syslog_debug("MAC Protocol Address 4: %02X:%02X:%02X:%02X:%02X:%02X",mac4_byte1, mac4_byte2, mac4_byte3, mac4_byte4, mac4_byte5, mac4_byte6);
	}
	if ( (type == 2) && (stype == 8)){
		if ((tods == true) && (fromds == true) ){	
			// QoS Control
			// Already bswaped_16!
			uint16bit = *((uint16_t *)(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + L_ADDR4));
			syslog_debug("MAC Protocol QoS: 0x%04X", uint16bit);
		} else{
			// QoS Control
			// Already bswaped_16!
			uint16bit = *((uint16_t *)(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ));
			syslog_debug("MAC Protocol QoS: 0x%04X", uint16bit);
		}
	}
#else
	// Type
	uint8bit = *ptr;
	type = (uint8bit & M_TYPE) >> 2;
	// Subtype
	stype = (uint8bit & M_S_TYPE) >> 4;
	// FLAGS
	uint8bit = *(ptr + 1);
	// To DS
	uint8bit_tmp = (uint8bit & M_FLAGS_TO_DS);
	tods = (uint8bit_tmp == 1) ? true : false;
	// From DS
	uint8bit_tmp = (uint8bit & M_FLAGS_FROM_DS) >> 1;
	fromds = (uint8bit_tmp == 1) ? true : false;
#endif

	// Evaluate mac_header_size;
	switch (type){
		case 0:
			switch(stype){
				case 4:
					mac_header_size = 24;
					break;
				default:
					return EBADMSG;
					break;
			}
			break;
		case 2:
			switch(stype){
				case 0:
					if ((tods == true) && (fromds == true) ){
						mac_header_size = 30;
					}else{
						mac_header_size = 24;
					}
					break;
				case 8:
					if ((tods == true) && (fromds == true) ){
						mac_header_size = 32;
					}else{
						mac_header_size = 26;
					}
					break;
				default:
					return EBADMSG;
					break;
			}
			break;
		default:
			return EBADMSG;
			break;
	}

	// Start fill short mac | MAC_DST | MAC_SRC | Payload
	dst_ptr = dst_packet;
	if ((!tods) && (!fromds)){
		// DA = Address 1 SA = Address 2
		// DA
		*(dst_ptr) = *(ptr + L_FC + L_DURATION);
		*(dst_ptr + 1) = *(ptr + L_FC + L_DURATION + 1);
		*(dst_ptr + 2) = *(ptr + L_FC + L_DURATION + 2);
		*(dst_ptr + 3) = *(ptr + L_FC + L_DURATION + 3);
		*(dst_ptr + 4) = *(ptr + L_FC + L_DURATION + 4);
		*(dst_ptr + 5) = *(ptr + L_FC + L_DURATION + 5);
		// SA
		*(dst_ptr + L_ADDR1) = *(ptr + L_FC + L_DURATION + L_ADDR1);
		*(dst_ptr + L_ADDR1 + 1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 1);
		*(dst_ptr + L_ADDR1 + 2) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 2);
		*(dst_ptr + L_ADDR1 + 3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 3);
		*(dst_ptr + L_ADDR1 + 4) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 4);
		*(dst_ptr + L_ADDR1 + 5) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 5);
		memcpy( (dst_ptr + L_ADDR1 + L_ADDR2), (src_packet + mac_header_size), ( (src_msg_size + 12) - mac_header_size)); 
		*dst_msg_size = ((src_msg_size + 12) - mac_header_size); 
	} else if ((!tods) && (fromds)){
		// DA = Address 1 SA = Address 3
		// DA
		*(dst_ptr) = *(ptr + L_FC + L_DURATION);
		*(dst_ptr + 1) = *(ptr + L_FC + L_DURATION + 1);
		*(dst_ptr + 2) = *(ptr + L_FC + L_DURATION + 2);
		*(dst_ptr + 3) = *(ptr + L_FC + L_DURATION + 3);
		*(dst_ptr + 4) = *(ptr + L_FC + L_DURATION + 4);
		*(dst_ptr + 5) = *(ptr + L_FC + L_DURATION + 5);
		// SA
		*(dst_ptr + L_ADDR1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2);
		*(dst_ptr + L_ADDR1 + 1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 1);
		*(dst_ptr + L_ADDR1 + 2) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 2);
		*(dst_ptr + L_ADDR1 + 3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 3);
		*(dst_ptr + L_ADDR1 + 4) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 4);
		*(dst_ptr + L_ADDR1 + 5) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 5);
		memcpy( (dst_ptr + L_ADDR1 + L_ADDR3), (src_packet + mac_header_size), ((src_msg_size + 12) - mac_header_size)); 
		*dst_msg_size = (src_msg_size + 12) - mac_header_size; 
	} else if ((tods) && (!fromds)){
		// DA = Address 3 SA = Address 2
		// DA
		*(dst_ptr) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2);
		*(dst_ptr + 1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 1);
		*(dst_ptr + 2) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 2);
		*(dst_ptr + 3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 3);
		*(dst_ptr + 4) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 4);
		*(dst_ptr + 5) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 5);
		// SA
		*(dst_ptr + L_ADDR3) = *(ptr + L_FC + L_DURATION + L_ADDR1);
		*(dst_ptr + L_ADDR3 + 1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 1);
		*(dst_ptr + L_ADDR3 + 2) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 2);
		*(dst_ptr + L_ADDR3 + 3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 3);
		*(dst_ptr + L_ADDR3 + 4) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 4);
		*(dst_ptr + L_ADDR3 + 5) = *(ptr + L_FC + L_DURATION + L_ADDR1 + 5);
		// Add Inverted packet from LLC layer.
		memcpy( (dst_ptr + L_ADDR3 + L_ADDR2), (src_packet + mac_header_size), ((src_msg_size + 12) - mac_header_size)); 
		*dst_msg_size = (src_msg_size + 12) - mac_header_size; 
	} else if ((tods) && (fromds)){
		// DA = Address 3 SA = Address 4
		// DA
		*(dst_ptr) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2);
		*(dst_ptr + 1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 1);
		*(dst_ptr + 2) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 2);
		*(dst_ptr + 3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 3);
		*(dst_ptr + 4) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 4);
		*(dst_ptr + 5) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 5);
		// SA
		*(dst_ptr + L_ADDR3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ);
		*(dst_ptr + L_ADDR3 + 1) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 1);
		*(dst_ptr + L_ADDR3 + 2) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 2);
		*(dst_ptr + L_ADDR3 + 3) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 3);
		*(dst_ptr + L_ADDR3 + 4) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 4);
		*(dst_ptr + L_ADDR3 + 5) = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 5);
		// Add Inverted packet from LLC layer.
		memcpy( (dst_ptr + L_ADDR3 + L_ADDR4), (src_packet + mac_header_size), ((src_msg_size + 12) - mac_header_size));
		*dst_msg_size = (src_msg_size + 12) - mac_header_size; 
	} else {
		// This should be Impossible!
		return EBADMSG;
	}

	return 0;
}

int it2s_mac_encap(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size, uint8_t *src_mac, uint8_t *dst_mac) {
    syslog_debug("MAC: Starting ENCAP");
	uint8_t *dst_ptr;
	uint8_t *src_ptr;
	int i;

	// Calculate destination size
	*dst_msg_size = src_msg_size + L_DATA_DATA;

	dst_ptr = dst_packet;
	src_ptr = src_packet;

	// FC
	*(dst_ptr) = 0x08; 
	*(dst_ptr + 1) = 0x00;
	// Duration/ID
	*(dst_ptr + L_FC) = 0x00; 
	*(dst_ptr + L_FC + 1) = 0x00;
	// DA
	memcpy (dst_ptr + L_FC + L_DURATION, dst_mac, L_ADDR1);
	// SA
	memcpy (dst_ptr + L_FC + L_DURATION + L_ADDR1, src_mac, L_ADDR2);
	// BSSID
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 1) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 2) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 3) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 4) = 0xFF;
	*(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 5) = 0xFF;
	// Sequence Control 
	*((uint16_t *)(dst_ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3)) = bswap_16(0x0000);
	// Copy Remaining message	
	memcpy(dst_ptr + L_DATA_DATA, src_ptr, src_msg_size);

    syslog_debug("MAC: Finished ENCAP");

	return 0;
}

int it2s_mac_decap(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size, uint8_t* src_mac, uint8_t* dst_mac){
    syslog_debug("MAC: Starting DECAP");
	uint8_t *ptr;
	uint8_t *src_ptr;
	uint8_t *dst_ptr;
	uint16_t uint16bit;
	uint8_t uint8bit;
	uint8_t uint8bit_tmp;
	uint16_t mac_header_size;
	int i;
	uint8_t type;
	uint8_t stype;
	bool tods;
	bool fromds;

#ifndef NDEBUG
	uint8_t protocol_version;
	uint8_t mac1_byte1;
	uint8_t mac1_byte2;
	uint8_t mac1_byte3;
	uint8_t mac1_byte4;
	uint8_t mac1_byte5;
	uint8_t mac1_byte6;
	uint8_t mac2_byte1;
	uint8_t mac2_byte2;
	uint8_t mac2_byte3;
	uint8_t mac2_byte4;
	uint8_t mac2_byte5;
	uint8_t mac2_byte6;
	uint8_t mac3_byte1;
	uint8_t mac3_byte2;
	uint8_t mac3_byte3;
	uint8_t mac3_byte4;
	uint8_t mac3_byte5;
	uint8_t mac3_byte6;
	uint8_t mac4_byte1;
	uint8_t mac4_byte2;
	uint8_t mac4_byte3;
	uint8_t mac4_byte4;
	uint8_t mac4_byte5;
	uint8_t mac4_byte6;
	uint16_t sq_sequence_number;
	uint16_t sq_frag_number;
	uint16_t duration_id;
	bool more_frag;
	bool retry;
	bool pwr_mgt;
	bool more_data;
	bool prf;
	bool order;
	bool duration_id_flag;
#endif

	if ( (src_packet == NULL) || (dst_packet == NULL) || (dst_msg_size == NULL) ){
		syslog_emerg("it2s_mac_remove_headers() failed: NULL pointer detected!");
		return EBADMSG;
	}

	// Keep Inverted pointer Safe.
	ptr = src_packet;

    memcpy(dst_mac, ptr + L_FC + L_DURATION, 6);
    memcpy(src_mac, ptr + L_FC + L_DURATION + L_ADDR1, 6);

#ifndef NDEBUG
	// Begin Decoding Frame Debug mode 
	// Frame Control
	// PV
	uint8bit = *ptr;
	protocol_version = (uint8bit & M_PV);
//	syslog_debug("MAC Protocol Version: %u", protocol_version);
	// Type
	type = (uint8bit & M_TYPE) >> 2;
	//syslog_debug("MAC Protocol Type: %u", type);
	// Subtype
	stype = (uint8bit & M_S_TYPE) >> 4;
	//syslog_debug("MAC Protocol Subtype: %u", stype);
	// FLAGS
	uint8bit = *(ptr + 1);
	// To DS
	uint8bit_tmp = (uint8bit & M_FLAGS_TO_DS);
	tods = (uint8bit_tmp == 1) ? true : false;
	//syslog_debug("MAC Protocol To DS: %d", tods);
	// From DS
	uint8bit_tmp = (uint8bit & M_FLAGS_FROM_DS) >> 1;
	fromds = (uint8bit_tmp == 1) ? true : false;
	//syslog_debug("MAC Protocol From DS: %d", fromds);
	// More Frag
	uint8bit_tmp = (uint8bit & M_FLAGS_MORE_FRAG) >> 2;
	more_frag = (uint8bit_tmp == 1) ? true : false;
	//syslog_debug("MAC Protocol More Frag: %d", more_frag);
	// Retry
	uint8bit_tmp = (uint8bit & M_FLAGS_RETRY) >> 3;
	retry = (uint8bit_tmp == 1) ? true : false;
//	syslog_debug("MAC Protocol Retry: %d", retry);
	// Pwr Mgt
	uint8bit_tmp = (uint8bit & M_FLAGS_PWR_MGT) >> 4;
	pwr_mgt = (uint8bit_tmp == 1) ? true : false;
//	syslog_debug("MAC Protocol Pwr Mgt: %d", pwr_mgt);
	// More Data
	uint8bit_tmp = (uint8bit & M_FLAGS_MORE_DATA) >> 5;
	more_data = (uint8bit_tmp == 1) ? true : false;
//	syslog_debug("MAC Protocol More Data: %d", more_data);
	// PrF
	uint8bit_tmp = (uint8bit & M_FLAGS_PRF) >> 6;
	prf = (uint8bit_tmp == 1) ? true : false;
//	syslog_debug("MAC Protocol PrF: %d", prf);
	// Order
	uint8bit_tmp = (uint8bit & M_FLAGS_ORDER) >> 7;
	order = (uint8bit_tmp == 1) ? true : false;
//	syslog_debug("MAC Protocol Order: %d", order);
	// Duration
	// Already bswaped_16!
	uint16bit = *((uint16_t *)(ptr + L_FC));
	duration_id = (uint16bit & M_DURATION_ID_FLAG) >> 15;
	duration_id_flag = (duration_id == 1) ? true : false;
//	syslog_debug("MAC Protocol Duration/ID flag: %d", duration_id_flag);
	if (duration_id_flag == 0){
		duration_id = (uint16bit & M_DURATION_ID_DURATION);
//		syslog_debug("MAC Protocol Duration/ID: %u", duration_id);
	} else {
//		syslog_debug("MAC Protocol Duration/ID: ID type found!");
	}
	// Address 1
	mac1_byte1 = *(ptr + L_FC + L_DURATION);
	mac1_byte2 = *(ptr + L_FC + L_DURATION + 1);
	mac1_byte3 = *(ptr + L_FC + L_DURATION + 2);
	mac1_byte4 = *(ptr + L_FC + L_DURATION + 3);
	mac1_byte5 = *(ptr + L_FC + L_DURATION + 4);
	mac1_byte6 = *(ptr + L_FC + L_DURATION + 5);
//	syslog_debug("MAC Protocol Address 1: %02X:%02X:%02X:%02X:%02X:%02X",mac1_byte1, mac1_byte2, mac1_byte3, mac1_byte4, mac1_byte5, mac1_byte6);
	// Address 2
	mac2_byte1 = *(ptr + L_FC + L_DURATION + L_ADDR1);
	mac2_byte2 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 1);
	mac2_byte3 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 2);
	mac2_byte4 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 3);
	mac2_byte5 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 4);
	mac2_byte6 = *(ptr + L_FC + L_DURATION + L_ADDR1 + 5);
//	syslog_debug("MAC Protocol Address 2: %02X:%02X:%02X:%02X:%02X:%02X",mac2_byte1, mac2_byte2, mac2_byte3, mac2_byte4, mac2_byte5, mac2_byte6);
	// Address 3
	mac3_byte1 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2);
	mac3_byte2 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 1);
	mac3_byte3 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 2);
	mac3_byte4 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 3);
	mac3_byte5 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 4);
	mac3_byte6 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + 5);
//	syslog_debug("MAC Protocol Address 3: %02X:%02X:%02X:%02X:%02X:%02X",mac3_byte1, mac3_byte2, mac3_byte3, mac3_byte4, mac3_byte5, mac3_byte6);
	// Sequence Control
	// Already bswaped_16!
	uint16bit = *((uint16_t *)(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3));
//	syslog_debug("MAC Protocol Sequence Control: 0x%04X",uint16bit);
	sq_frag_number = (uint16bit & M_SQ_FRAG_NUMBER);
//	syslog_debug("MAC Protocol Sequence Control Frag Number: %u", sq_frag_number);
	sq_sequence_number = (uint16bit & M_SQ_SEQUENCE_NUMBER) >> 4;
//	syslog_debug("MAC Protocol Sequence Control Sequence Number: %u", sq_sequence_number);
	if ((tods == true) && (fromds == true) ){	
		// Address 4
		mac4_byte1 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ);
		mac4_byte2 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 1);
		mac4_byte3 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 2);
		mac4_byte4 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 3);
		mac4_byte5 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 4);
		mac4_byte6 = *(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + 5);
//		syslog_debug("MAC Protocol Address 4: %02X:%02X:%02X:%02X:%02X:%02X",mac4_byte1, mac4_byte2, mac4_byte3, mac4_byte4, mac4_byte5, mac4_byte6);
	}
	if ( (type == 2) && (stype == 8)){
		if ((tods == true) && (fromds == true) ){	
			// QoS Control
			// Already bswaped_16!
			uint16bit = *((uint16_t *)(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ + L_ADDR4));
	//		syslog_debug("MAC Protocol QoS: 0x%04X", uint16bit);
		} else{
			// QoS Control
			// Already bswaped_16!
			uint16bit = *((uint16_t *)(ptr + L_FC + L_DURATION + L_ADDR1 + L_ADDR2 + L_ADDR3 + L_SQ));
//			syslog_debug("MAC Protocol QoS: 0x%04X", uint16bit);
		}
	}
#else
	// Type
	uint8bit = *ptr;
	type = (uint8bit & M_TYPE) >> 2;
	// Subtype
	stype = (uint8bit & M_S_TYPE) >> 4;
	// FLAGS
	uint8bit = *(ptr + 1);
	// To DS
	uint8bit_tmp = (uint8bit & M_FLAGS_TO_DS);
	tods = (uint8bit_tmp == 1) ? true : false;
	// From DS
	uint8bit_tmp = (uint8bit & M_FLAGS_FROM_DS) >> 1;
	fromds = (uint8bit_tmp == 1) ? true : false;
#endif

	// Evaluate mac_header_size;
	switch (type){
		case 0:
			switch(stype){
				case 4:
					mac_header_size = 24;
					break;
				default:
					return EBADMSG;
					break;
			}
			break;
		case 2:
			switch(stype){
				case 0:
					if ((tods == true) && (fromds == true) ){
						mac_header_size = 30;
					}else{
						mac_header_size = 24;
					}
					break;
				case 8:
					if ((tods == true) && (fromds == true) ){
						mac_header_size = 32;
					}else{
						mac_header_size = 26;
					}
					break;
				default:
					return EBADMSG;
					break;
			}
			break;
		default:
			return EBADMSG;
			break;
	}

	memcpy(dst_packet, src_packet + mac_header_size,  src_msg_size - mac_header_size); 
	*dst_msg_size = src_msg_size - mac_header_size; 

    syslog_debug("MAC: Finished DECAP");
	return 0;
}

