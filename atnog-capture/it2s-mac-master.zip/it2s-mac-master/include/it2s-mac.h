#ifndef IT2S_MAC_H
#define IT2S_MAC_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

// Generate a lookup table for 32bit operating system
// using macro
#define R2(n)     n,     n + 2*64,     n + 1*64,     n + 3*64
#define R4(n) R2(n), R2(n + 2*16), R2(n + 1*16), R2(n + 3*16)
#define R6(n) R4(n), R4(n + 2*4 ), R4(n + 1*4 ), R4(n + 3*4 )

// Lookup table that store the reverse of each table
unsigned int lookuptable[256] = { R6(0), R6(2), R6(1), R6(3) };

#define MAC_VERSION 0

/* Header lengths */
#define L_FC 2
#define L_DURATION 2
#define L_ADDR1 6
#define L_ADDR2 6
#define L_ADDR3 6
#define L_SQ 2
#define L_ADDR4 6
#define L_QOS 2
#define L_MANAGEMENT_ASSOCIATION_REQUEST 0
#define L_MANAGEMENT_PROBE_REQUEST 24
#define L_DATA_DATA 24
#define L_DATA_QOS_DATA 24

/* Masks */
#define M_PV 0x03
#define M_TYPE 0x0C
#define M_S_TYPE 0xF0
#define M_FLAGS_TO_DS 0x01
#define M_FLAGS_FROM_DS 0x02
#define M_FLAGS_MORE_FRAG 0x04
#define M_FLAGS_RETRY 0x08
#define M_FLAGS_PWR_MGT 0x10
#define M_FLAGS_MORE_DATA 0X20
#define M_FLAGS_PRF 0x40
#define M_FLAGS_ORDER 0x80
#define M_SQ_FRAG_NUMBER 0x000F
#define M_SQ_SEQUENCE_NUMBER 0xFFF0
#define M_DURATION_ID_FLAG 0x8000
#define M_DURATION_ID_DURATION 0x7FFF

/* Function to reverse bits of num */
uint8_t reverseBits(uint8_t num);

int it2s_mac_add_headers(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size);
int it2s_mac_add_headers_without_inversion(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size);
int it2s_mac_encap(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size, uint8_t *src_mac, uint8_t *dst_mac);

int it2s_mac_remove_headers(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size);
int it2s_mac_remove_headers_without_inversion(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size);
int it2s_mac_decap(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size, uint8_t *src_mac, uint8_t* dst_mac);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif /* IT2S_MAC_H */
