#ifndef IT2S_LLC_H
#define IT2S_LLC_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/* Header lengths */
#define L_LLC_DSAP		   				 1
#define L_LLC_SSAP		   				 1
#define L_LLC_CONTROL		 				 1
#define L_LLC_ORGANIZATION_ID		 3
#define L_LLC_ETHERTYPE		 			 2
#define L_LLC_SHORT_MAC					 12
#define L_LLC_HEADER					   8

/* Masks */
#define M_DURATION_ID_DURATION  0x7FFF

int it2s_llc_remove_headers(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size);
int it2s_llc_decap(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size, uint16_t* ether_type);

int it2s_llc_add_headers(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size);
int it2s_llc_encap(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size, uint16_t ether_type);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif /* IT2S_LLC_H */
