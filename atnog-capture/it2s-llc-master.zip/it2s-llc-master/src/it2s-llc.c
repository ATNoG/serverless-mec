#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
#include <syslog.h>          /* logging */
#include <byteswap.h>
#include <stdbool.h>
#include "it2s-llc.h"
#include <inttypes.h>
#include <time.h>

#define syslog_emerg(msg, ...) syslog(LOG_EMERG, "%s:%d [" msg "]", __func__, __LINE__, ##__VA_ARGS__)
#define syslog_err(msg, ...)   syslog(LOG_ERR  , "%s:%d [" msg "]", __func__, __LINE__, ##__VA_ARGS__)

#ifndef NDEBUG
//#define syslog_debug(msg, ...) syslog(LOG_DEBUG, "%s(%s:%d) [" msg "]", __FILE__, __func__, __LINE__, ##__VA_ARGS__)
#define syslog_debug(msg, ...) syslog(LOG_DEBUG, "%s:%d [" msg "]", __func__, __LINE__, ##__VA_ARGS__)
#else
#define syslog_debug(msg, ...)
#endif

int it2s_llc_add_headers(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size){
	uint8_t *buffer;
	uint8_t *dst_ptr;
	uint8_t *src_ptr;
	
	if ( (src_packet == NULL) || (dst_packet == NULL) || (dst_msg_size == NULL) ){
		syslog_emerg("it2s_llc_add_headers() failed: NULL pointer detected!");
		return EBADMSG;
	}
	
	*dst_msg_size = src_msg_size + (L_LLC_HEADER - L_LLC_ETHERTYPE);
	
	dst_ptr = dst_packet;
	src_ptr = src_packet;

	// Copy MAC DA and MAC SA 
	memcpy(dst_ptr, src_ptr, L_LLC_SHORT_MAC);
	// Add DSAP
	*(dst_ptr + L_LLC_SHORT_MAC) = 0xAA; 
	// Add SSAP
	*(dst_ptr + L_LLC_SHORT_MAC + L_LLC_DSAP) = 0xAA; 
	// Add Control
	*(dst_ptr + L_LLC_SHORT_MAC + L_LLC_DSAP + L_LLC_SSAP) = 0x03;
	// Add Organization ID:
	*(dst_ptr + L_LLC_SHORT_MAC + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL) = 0x00;
	*(dst_ptr + L_LLC_SHORT_MAC + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + 1) = 0x00;
	*(dst_ptr + L_LLC_SHORT_MAC + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + 2) = 0x00;
	// Add Ethertype
	*((uint16_t *)(dst_ptr + L_LLC_SHORT_MAC + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + L_LLC_ORGANIZATION_ID)) = bswap_16(0x8947);
	// Copy Remaining message
	memcpy(dst_ptr + L_LLC_SHORT_MAC + L_LLC_HEADER, src_ptr + L_LLC_SHORT_MAC + L_LLC_ETHERTYPE, src_msg_size - (L_LLC_SHORT_MAC + L_LLC_ETHERTYPE));
	
	return 0;
}

int it2s_llc_remove_headers(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size){
	uint8_t *ptr;
	uint8_t *dst_ptr;
	uint16_t uint16bit;
	uint16_t ethertype;
	uint8_t uint8bit;
	uint8_t uint8bit_tmp;
	uint16_t mac_header_size;
#ifndef NDEBUG
 uint8_t oid_1;
 uint8_t oid_2;
 uint8_t oid_3;
#endif

	// Keep Buffer pointer Safe.
	ptr = src_packet + L_LLC_SHORT_MAC;

#ifndef NDEBUG
	// Begin Decoding Frame Debug mode 
	// DSAP
	uint8bit = *ptr;
	syslog_debug("LLC DSAP: 0x%02X", uint8bit);
	// SSAP
	uint8bit = *(ptr + L_LLC_DSAP);
	syslog_debug("LLC SSAP: 0x%02X", uint8bit);
	// Control
	uint8bit = *(ptr + L_LLC_DSAP + L_LLC_SSAP);
	syslog_debug("LLC Control: 0x%02X", uint8bit);
	// Organization ID
	oid_1 = *(ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL);
	oid_2 = *(ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + 1);
	oid_3 = *(ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + 2);
	syslog_debug("LLC Organization ID: 0x%02X%02X%02X", oid_1, oid_2, oid_3);
	// EtherType
	ethertype = bswap_16(*((uint16_t *)(ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + L_LLC_ORGANIZATION_ID)));
	syslog_debug("LLC Ethertype: 0x%04X", ethertype);
#else
	// EtherType
	ethertype = bswap_16(*((uint16_t *)(ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + L_LLC_ORGANIZATION_ID)));
#endif

	// Discard non Geonetworking Packets
	if (ethertype != 0x8947){
		syslog_err("Invalid Ethertype: %04X", ethertype);
		return EBADMSG;
	}
	
	// Start fill short Short MAC + Short LLC
	dst_ptr = dst_packet;
	// Copy MAC DA and MAC SA 
	memcpy(dst_ptr, src_packet, L_LLC_SHORT_MAC);
	// Add Ethertype
	*((uint16_t *)(dst_ptr + L_LLC_SHORT_MAC)) = bswap_16(ethertype);
	// Add Remaining of Buffer
	memcpy(dst_ptr + L_LLC_SHORT_MAC + L_LLC_ETHERTYPE, src_packet + L_LLC_SHORT_MAC + L_LLC_HEADER, src_msg_size - (L_LLC_SHORT_MAC + L_LLC_HEADER));
	// Update msg_size
	*dst_msg_size = src_msg_size - (L_LLC_HEADER - L_LLC_ETHERTYPE);

	return 0;
}

int it2s_llc_encap(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size, uint16_t ether_type) {
    syslog_debug("LLC: Starting ENCAP");
	uint8_t *buffer;
	uint8_t *dst_ptr;
	uint8_t *src_ptr;
	
	*dst_msg_size = src_msg_size + L_LLC_HEADER;
	
	dst_ptr = dst_packet;
	src_ptr = src_packet;

	// Add DSAP
	*(dst_ptr) = 0xAA; 
	// Add SSAP
	*(dst_ptr + L_LLC_DSAP) = 0xAA; 
	// Add Control
	*(dst_ptr + L_LLC_DSAP + L_LLC_SSAP) = 0x03;
	// Add Organization ID:
	*(dst_ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL) = 0x00;
	*(dst_ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + 1) = 0x00;
	*(dst_ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + 2) = 0x00;
	// Add Ethertype
	*((uint16_t *)(dst_ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + L_LLC_ORGANIZATION_ID)) = bswap_16(ether_type);
	// Copy Remaining message
	memcpy(dst_ptr + L_LLC_HEADER, src_ptr, src_msg_size);

    syslog_debug("LLC: Finished ENCAP");
    return 0;
}

int it2s_llc_decap(uint8_t *src_packet, uint16_t src_msg_size, uint8_t *dst_packet, uint32_t *dst_msg_size, uint16_t* ether_type){
    syslog_debug("LLC: Starting DECAP");
	uint8_t *ptr;
	uint8_t *dst_ptr;
	uint16_t uint16bit;
	uint8_t uint8bit;
	uint8_t uint8bit_tmp;
	uint16_t mac_header_size;
#ifndef NDEBUG
    uint8_t oid_1;
    uint8_t oid_2;
    uint8_t oid_3;
#endif

	// Keep Buffer pointer Safe.
	ptr = src_packet;

#ifndef NDEBUG
	// Begin Decoding Frame Debug mode 
	// DSAP
	uint8bit = *ptr;
//	syslog_debug("LLC DSAP: 0x%02X", uint8bit);
	// SSAP
	uint8bit = *(ptr + L_LLC_DSAP);
//	syslog_debug("LLC SSAP: 0x%02X", uint8bit);
	// Control
	uint8bit = *(ptr + L_LLC_DSAP + L_LLC_SSAP);
//	syslog_debug("LLC Control: 0x%02X", uint8bit);
	// Organization ID
	oid_1 = *(ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL);
	oid_2 = *(ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + 1);
	oid_3 = *(ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + 2);
//	syslog_debug("LLC Organization ID: 0x%02X%02X%02X", oid_1, oid_2, oid_3);
	// EtherType
	*ether_type = bswap_16(*((uint16_t *)(ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + L_LLC_ORGANIZATION_ID)));
//	syslog_debug("LLC Ethertype: 0x%04X", ethertype);
#else
	// EtherType
	*ether_type = bswap_16(*((uint16_t *)(ptr + L_LLC_DSAP + L_LLC_SSAP + L_LLC_CONTROL + L_LLC_ORGANIZATION_ID)));
#endif

	// Discard non Geonetworking packets and non IPv6 packets
	if (*ether_type != 0x8947 && *ether_type != 0x86dd && *ether_type != 0x88dc){
		syslog_err("Invalid Ethertype: %04X", *ether_type);
		return EBADMSG;
	}
	
    memcpy(dst_packet, src_packet + L_LLC_HEADER, src_msg_size - L_LLC_HEADER);
	*dst_msg_size = src_msg_size - L_LLC_HEADER;

    syslog_debug("LLC: Finished DECAP");
	return 0;
}
